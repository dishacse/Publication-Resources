# __init__.py
"""
my_filter_package: A package for filtering text using regex and OpenAI's API.
"""
